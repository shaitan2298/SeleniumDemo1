package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition
{
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setUpStepEnv()
	{
		 System.setProperty("webdriver.chrome.driver", "D:\\3000117_Ankita_Dutta\\BDDCucumberSelenium\\chromedriver.exe");
	}
	
	@Given("^User is on the login page of www\\.github\\.com$")
	public void user_is_on_the_login_page_of_www_github_com() throws Throwable {
	   driver = new ChromeDriver();
	   driver.get("https://github.com/login");
	   loginPage = PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enters invalid username and password$")
	public void user_enters_invalid_username_and_password() throws Throwable {
	    loginPage.setUsername("shaitan2298");
	    loginPage.setPassword("Papa");
	    loginPage.clickSignIn();
	}

	@Then("^'Incorrect username or password' is displayed$")
	public void incorrect_username_or_password_is_displayed() throws Throwable {
	    String expectedErrorMessage = "Incorrect username or password.";
	    Assert.assertEquals(expectedErrorMessage,loginPage.getActualErrorMessage());
	}

	@When("^User enters valid username and valid password$")
	public void user_enters_valid_username_and_valid_password() throws Throwable {
	   loginPage.setUsername("shaitan2298");
	   loginPage.setPassword("Ankita$123");
	   loginPage.toString();
	}

	@Then("^User is directed to the success page$")
	public void user_is_directed_to_the_success_page() throws Throwable {
	   String actualTitle = driver.getTitle();
	    String expectedTitle = "Sign in to GitHub � GitHub";
	    Assert.assertEquals(expectedTitle,actualTitle);
	}
	
	@After
    public void tearDownStepEnv()
    {
		driver.close();
    }
}
